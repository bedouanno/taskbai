        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="<?php echo base_url(); ?>/assetsv2/images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="<?php echo base_url(); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url(); ?>clients">
                                <i class="fas fa-briefcase"></i>Clients</a>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-tasks"></i>Tasks <small class="float-right mt-1"><span class="badge badge-danger mr-2">49</span> <i class="fas fa-chevron-down"></i></small></a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?php echo base_url(); ?>tasks"><i class="fas fa-tasks"></i> Today's Task</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url(); ?>tasks/history"><i class="fas fa-tasks"></i> Task History</a>
                                </li>
                            </ul>
                        </li>
                        <hr>
                        <li class="nav-item">
                            <a class="nav-link" target="_blank" href="https://www.xara.com/us/designer-pro/tutorials-demos/#video_player">
                                <i class="fas fa-fw fa-bookmark"></i>
                                <span>XARA Video Tutorials</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" target="_blank" href="https://web4.proweaverlinks.com/stockphotos/">
                                <i class="fas fa-fw fa-bookmark"></i>
                                <span>Stock Photos</span></a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" target="_blank" href="https://drive.google.com/drive/folders/1voh_BN3yYnBNuk89VXv8wpHjGC1dprIa?usp=sharing">
                                <i class="fas fa-fw fa-bookmark"></i>
                                <span>Social Media Icons</span></a>
                        </li> -->
                        <hr>
                        <?php if($user_info['role'] == 1): ?>  
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-gear"></i>Admin Tools <i class="fas fa-chevron-down float-right mt-1"></i></a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="<?php echo base_url(); ?>users"><i class="fas fa-users"></i>Users</a>
                                </li>
                            </ul>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->